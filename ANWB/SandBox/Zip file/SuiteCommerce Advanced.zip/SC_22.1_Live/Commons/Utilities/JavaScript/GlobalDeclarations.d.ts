/*
	© 2020 NetSuite Inc.
	User may not copy, modify, distribute, or re-bundle or otherwise make available this code;
	provided, however, if you are an authorized user with a NetSuite account or log-in, you
	may use this code subject to the terms that govern your access and use.
*/

/*export var NSJQuery :any;*/

declare var SC: any;
declare var window: Window & typeof globalThis;
declare var session: any;
declare var INTRUMENT_BC_ARGUMENT: any;
declare var INTRUMENT_BC_SERVER: any;
declare var nsglobal: any;
declare var MODULES_CONFIG: any;
declare var addthis: any;
declare var google: any;
declare var srcRequire: any;
