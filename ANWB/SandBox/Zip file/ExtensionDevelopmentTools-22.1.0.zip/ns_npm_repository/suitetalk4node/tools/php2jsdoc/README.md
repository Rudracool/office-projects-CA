#suitetalk php2jsdoc tool

this project generates jsdoc document from netsuite's php webservice implementation . It generates / uses https://github.com/cancerberoSgx/short-jsdoc. 

##Usage

    node php2jsdoc.js
    firefox jsdoc/index.html
