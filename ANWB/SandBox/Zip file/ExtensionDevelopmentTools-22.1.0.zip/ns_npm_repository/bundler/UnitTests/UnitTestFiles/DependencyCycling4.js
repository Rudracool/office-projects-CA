define('DependencyCycling4', ['DependencyCycling5'], function() {});
