define('EmptyDependencyEntryPoint1', [''], function() {});
