define('EntryPointConfigContent', [
    'DependencyPath',
    'DependencyShim',
    'DependencyMap1'
], function() {});
