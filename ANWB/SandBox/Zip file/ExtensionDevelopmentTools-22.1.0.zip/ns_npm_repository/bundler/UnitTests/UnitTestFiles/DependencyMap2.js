define('DependencyMap2', function() {});
