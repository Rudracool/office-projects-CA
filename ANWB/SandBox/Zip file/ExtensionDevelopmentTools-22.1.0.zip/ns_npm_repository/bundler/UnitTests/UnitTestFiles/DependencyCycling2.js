define('DependencyCycling2', ['DependencyCycling4'], function() {});
