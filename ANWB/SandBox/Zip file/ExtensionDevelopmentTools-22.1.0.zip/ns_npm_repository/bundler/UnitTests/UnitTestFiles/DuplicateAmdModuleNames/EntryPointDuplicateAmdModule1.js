define('EntryPointDuplicateAmdModule1', function() {});
