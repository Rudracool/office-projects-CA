define('EntryPointEmptyDefine3', ['DependencyEmptyDefineWithArrayWithValues'], function() {});
