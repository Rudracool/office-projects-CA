// <%= module_name %>.js
// Load all your starter dependencies in backend for your extension here
// ----------------

define('<%= module_name %>'
,	[
		'<%= module_name %>.ServiceController'
	]
,	function (
		<%= module_dep_name %>ServiceController
	)
{
	'use strict';
});