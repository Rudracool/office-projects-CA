define('EntryPoint1', function() {});
