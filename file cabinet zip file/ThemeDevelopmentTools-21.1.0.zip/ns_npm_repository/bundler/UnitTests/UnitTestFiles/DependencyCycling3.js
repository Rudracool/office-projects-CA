define('DependencyCycling3', ['DependencyCycling1'], function() {});
