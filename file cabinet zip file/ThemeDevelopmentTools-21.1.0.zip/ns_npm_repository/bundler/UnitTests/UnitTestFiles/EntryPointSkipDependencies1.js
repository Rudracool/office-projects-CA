define('EntryPointSkipDependencies1', [
    'SkipDependency1',
    'SkipDependency2',
    'Dependency3'
], function() {});
