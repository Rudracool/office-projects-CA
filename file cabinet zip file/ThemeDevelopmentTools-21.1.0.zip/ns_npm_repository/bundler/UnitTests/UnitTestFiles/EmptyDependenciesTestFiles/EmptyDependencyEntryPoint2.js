/* eslint-disable */
define('EmptyDependencyEntryPoint2', ['Dependency1',], function() {});
