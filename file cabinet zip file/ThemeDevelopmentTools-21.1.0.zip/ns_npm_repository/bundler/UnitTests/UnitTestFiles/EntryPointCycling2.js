define('EntryPointCycling2', ['DependencyCycling2'], function() {});
