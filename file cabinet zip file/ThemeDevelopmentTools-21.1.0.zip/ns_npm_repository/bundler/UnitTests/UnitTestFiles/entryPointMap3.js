define('EntryPointMap3', ['DependencyMap2'], function() {});
